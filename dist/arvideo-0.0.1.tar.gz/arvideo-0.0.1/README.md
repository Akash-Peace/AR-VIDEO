## arvideo
arvideo is a python module used to hologram a video in a real-world entity surrounded with ArUco markers.

